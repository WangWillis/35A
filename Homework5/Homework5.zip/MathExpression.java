interface MathExpression
{
	public double evaluate();
}